### JBoss

This plugin works with JBoss Application Server to manage the deployed applications, as well viewing information about connectors, and JMX, etc.

