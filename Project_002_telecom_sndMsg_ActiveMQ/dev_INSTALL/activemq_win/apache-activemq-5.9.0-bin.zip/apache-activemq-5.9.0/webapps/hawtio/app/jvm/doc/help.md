### JVM

This plugin lists local JVMs running on your machine and allows you to install the Jolokia JVM agent into a running JVM and connect to it.

For this to actually work you need to have your JDK's "tools.jar" in the classpath, along with Jolokia's JVM agent jar.

