The **Fabric** plugin contains views and directives that interact and manage Fuse Fabric.

## Fabric widgets
<div ng-include="'app/fabric/html/test.html'"></div>
